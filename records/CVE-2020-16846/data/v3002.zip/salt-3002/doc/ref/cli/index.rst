======================
Command Line Reference
======================

salt-api
========
.. toctree::

    salt-api

salt-call
=========
.. toctree::

    salt-call

salt
====
.. toctree::

    salt

salt-cloud
==========
.. toctree::

    salt-cloud

salt-cp
=======
.. toctree::

    salt-cp

salt-extend
===========
.. toctree::

    salt-extend

salt-key
========
.. toctree::

    salt-key

salt-master
===========
.. toctree::

    salt-master

salt-minion
===========
.. toctree::

    salt-minion

salt-proxy
==========
.. toctree::

    salt-proxy

salt-run
========
.. toctree::

    salt-run

salt-ssh
========
.. toctree::

    salt-ssh

salt-syndic
===========
.. toctree::

    salt-syndic

salt-unity
==========
.. toctree::

    salt-unity

spm
===
.. toctree::

    spm
