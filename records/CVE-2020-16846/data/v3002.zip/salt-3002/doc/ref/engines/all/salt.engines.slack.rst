salt.engines.slack module
=========================

.. automodule:: salt.engines.slack
    :members:
