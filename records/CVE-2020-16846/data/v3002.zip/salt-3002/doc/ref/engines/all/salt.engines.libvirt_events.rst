salt.engines.libvirt_events module
==================================

.. automodule:: salt.engines.libvirt_events
    :members:
    :undoc-members:
