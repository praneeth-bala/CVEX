==============
salt.auth.auto
==============

.. automodule:: salt.auth.auto
    :members: