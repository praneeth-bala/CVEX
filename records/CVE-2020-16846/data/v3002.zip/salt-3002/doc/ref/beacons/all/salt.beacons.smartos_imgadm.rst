salt.beacons.smartos_imgadm module
==================================

.. automodule:: salt.beacons.smartos_imgadm
    :members:
