salt.cache.consul
=================

.. automodule:: salt.cache.consul
    :members:
