.. _all-salt.cache:

=============
cache modules
=============

.. currentmodule:: salt.cache

.. autosummary::
    :toctree:
    :template: autosummary.rst.tmpl

    consul
    etcd_cache
    localfs
    mysql_cache
    redis_cache
