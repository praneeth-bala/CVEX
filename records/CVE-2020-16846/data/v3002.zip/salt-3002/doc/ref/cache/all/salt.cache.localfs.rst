salt.cache.localfs
==================

.. automodule:: salt.cache.localfs
    :members:
