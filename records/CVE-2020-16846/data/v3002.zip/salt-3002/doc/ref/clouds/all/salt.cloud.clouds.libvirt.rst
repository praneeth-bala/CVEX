=========================
salt.cloud.clouds.libvirt
=========================

.. automodule:: salt.cloud.clouds.libvirt
    :members:
