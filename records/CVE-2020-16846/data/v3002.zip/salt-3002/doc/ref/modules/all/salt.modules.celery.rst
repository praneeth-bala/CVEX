salt.modules.celery module
==========================

.. automodule:: salt.modules.celery
    :members:
    :undoc-members:
