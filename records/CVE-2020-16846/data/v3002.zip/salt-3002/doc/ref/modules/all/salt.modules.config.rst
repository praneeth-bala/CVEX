===================
salt.modules.config
===================

.. automodule:: salt.modules.config
    :members: