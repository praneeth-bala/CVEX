salt.modules.esxvm module
=========================

.. automodule:: salt.modules.esxvm
    :members:
    :undoc-members:
