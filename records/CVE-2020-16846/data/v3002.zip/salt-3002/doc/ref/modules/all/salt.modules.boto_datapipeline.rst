salt.modules.boto_datapipeline module
=====================================

.. automodule:: salt.modules.boto_datapipeline
    :members:
