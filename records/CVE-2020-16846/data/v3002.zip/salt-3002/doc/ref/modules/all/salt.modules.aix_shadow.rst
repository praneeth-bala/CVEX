salt.modules.aix_shadow module
==============================

.. automodule:: salt.modules.aix_shadow
    :members:
    :undoc-members:
