salt.modules.boto3_elasticsearch module
=======================================

.. automodule:: salt.modules.boto3_elasticsearch
    :members:
