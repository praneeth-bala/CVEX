=========================
salt.modules.linux_shadow
=========================

.. automodule:: salt.modules.linux_shadow
    :members:
