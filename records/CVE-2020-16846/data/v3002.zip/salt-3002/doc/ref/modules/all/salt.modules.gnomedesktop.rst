=========================
salt.modules.gnomedesktop
=========================

.. automodule:: salt.modules.gnomedesktop
    :members: