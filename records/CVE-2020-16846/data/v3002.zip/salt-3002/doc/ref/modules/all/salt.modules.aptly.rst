salt.modules.aptly module
=========================

.. automodule:: salt.modules.aptly
    :members:
    :undoc-members:
