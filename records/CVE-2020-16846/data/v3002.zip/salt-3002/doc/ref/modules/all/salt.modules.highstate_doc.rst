salt.modules.highstate_doc module
=================================

.. automodule:: salt.modules.highstate_doc
    :members:
    :undoc-members:
