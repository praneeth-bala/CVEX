===============
salt.modules.cp
===============

.. automodule:: salt.modules.cp
    :members: