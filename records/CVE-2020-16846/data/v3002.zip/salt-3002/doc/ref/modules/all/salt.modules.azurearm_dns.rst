salt.modules.azurearm_dns module
================================

.. automodule:: salt.modules.azurearm_dns
    :members:
    :undoc-members:
