salt.modules.github module
==========================

.. automodule:: salt.modules.github
    :members:
