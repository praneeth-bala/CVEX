===================
salt.modules.grains
===================

.. automodule:: salt.modules.grains
    :members: