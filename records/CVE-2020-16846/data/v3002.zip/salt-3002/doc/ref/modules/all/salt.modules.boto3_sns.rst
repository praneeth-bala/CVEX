salt.modules.boto3_sns module
=============================

.. automodule:: salt.modules.boto3_sns
    :members:
    :undoc-members:
