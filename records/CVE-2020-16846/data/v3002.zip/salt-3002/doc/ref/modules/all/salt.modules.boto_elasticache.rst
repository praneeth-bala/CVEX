=============================
salt.modules.boto_elasticache
=============================

.. automodule:: salt.modules.boto_elasticache
    :members: