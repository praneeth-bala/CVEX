==========================
salt.modules.linux_service
==========================

.. automodule:: salt.modules.linux_service
    :members:
