=================
salt.grains.mdata
=================

.. automodule:: salt.grains.mdata
    :members:
