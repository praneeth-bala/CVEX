======================
salt.grains.ssh_sample
======================

.. automodule:: salt.grains.ssh_sample
    :members:
